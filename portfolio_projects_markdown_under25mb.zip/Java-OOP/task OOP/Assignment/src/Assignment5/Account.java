package Assignment5;

import java.util.Date;

public class Account {
    private int id;
    private double balance;
    private double annualInterestRate;
    private Date dateCreated;

    public Account() {
        this.id = 0;
        this.balance = 0;
        this.annualInterestRate = 0;
        this.dateCreated = new Date();
    }

    public Account(int id, double balance) {
        this.id = id;
        this.balance = balance;
        this.annualInterestRate = 0;
        this.dateCreated = new Date();
    }

    public double getMonthlyInterestRate() {
        return annualInterestRate / 12 / 100;
    }

    public double getMonthlyInterest() {
        return balance * getMonthlyInterestRate();
    }

    public void withdraw(double amount) {
        balance -= amount;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public double getBalance() { return balance; }
    public Date getDateCreated() { return dateCreated; }
    public void setAnnualInterestRate(double rate) { this.annualInterestRate = rate; }

    public static void main(String[] args) {
        Account acc = new Account(1122, 20000);
        acc.setAnnualInterestRate(4.5);

        acc.withdraw(2500);
        acc.deposit(3000);

        System.out.println("Balance = " + acc.getBalance());
        System.out.println("Monthly Interest = " + acc.getMonthlyInterest());
        System.out.println("Date Created = " + acc.getDateCreated());
    }
}
