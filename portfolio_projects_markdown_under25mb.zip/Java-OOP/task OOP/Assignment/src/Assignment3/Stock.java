package Assignment3;

public class Stock {
    String symbol;
    String name;
    double previousClosingPrice;
    double currentPrice;

    public Stock(String symbol, String name, double previousClosingPrice, double currentPrice) {
        this.symbol = symbol;
        this.name = name;
        this.previousClosingPrice = previousClosingPrice;
        this.currentPrice = currentPrice;
    }

    public double changePercent() {
        return ((currentPrice - previousClosingPrice) / previousClosingPrice) * 100;
    }

    public static void main(String[] args) {
        Stock s = new Stock("ORCL", "Oracle Corporation", 34.5, 33.35);
        System.out.println("Stock: "+"("+s.name+")");
        System.out.println("Pervious price: "+s.previousClosingPrice);
        System.out.println("Current price: "+s.currentPrice);
        System.out.println("Price-change percentage = " + s.changePercent() + "%");
    }
}
