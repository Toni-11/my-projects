package Assignment3;

public class Rectangle {
    double width;
    double height;

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public double calculateArea() {
        return width * height;
    }

    public double calculatePerimeter() {
        return 2 * (width + height);
    }

    public static void main(String[] args) {
        Rectangle r1 = new Rectangle(4, 40);
        Rectangle r2 = new Rectangle(3.5, 35.9);

        System.out.println("Rectangle 1: width=" + r1.width + ", height=" + r1.height +
                ", area=" + r1.calculateArea() + ", perimeter=" + r1.calculatePerimeter());

        System.out.println("Rectangle 2: width=" + r2.width + ", height=" + r2.height +
                ", area=" + r2.calculateArea() + ", perimeter=" + r2.calculatePerimeter());
    }
}
