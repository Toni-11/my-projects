package Assignment3;

import java.sql.SQLOutput;
import java.util.Scanner;

public class QuadraticEquation {
    double a, b, c;

    public QuadraticEquation(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double discriminant() {

        return b * b - 4 * a * c;
    }

    public double calcRoot1() {
        double d = discriminant();
        if (d < 0||a==0) return 0;
        return (-b + Math.sqrt(d)) / (2 * a);
    }

    public double calcRoot2() {
        double d = discriminant();
        if (d < 0||a==0) return 0;
        return (-b - Math.sqrt(d)) / (2 * a);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a, b, c: ");
        double a = input.nextDouble();
        double b = input.nextDouble();
        double c = input.nextDouble();

        QuadraticEquation eq = new QuadraticEquation(a, b, c);
        double d = eq.discriminant();
        if(a==0){
            System.out.println("a=0 , not a quadratic equation");
        }
        if (d > 0) {
            System.out.println("Root1 = " + eq.calcRoot1() +"\n"+ "Root2 = " + eq.calcRoot2());
        } else if (d == 0) {
            System.out.println("One root = " + eq.calcRoot1());
        } else {
            System.out.println("The equation has no roots.");
        }
    }
}
