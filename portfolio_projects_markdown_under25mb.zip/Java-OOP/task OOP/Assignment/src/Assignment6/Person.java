package Assignment6;

import java.util.Date;

public class Person {
    String name, address, phone, email;

    public Person(String name, String address, String phone, String email) {
        this.name = name; this.address = address; this.phone = phone; this.email = email;
    }

    @Override
    public String toString() {
        return "Person: " + name;
    }
}

class Student extends Person {
    public static final String FRESHMAN = "Freshman";
    public static final String JUNIOR = "Junior";
    public static final String SENIOR = "Senior";
    String status;

    public Student(String name, String address, String phone, String email, String status) {
        super(name, address, phone, email);
        this.status = status;
    }

    @Override
    public String toString() {
        return "Student: " + name;
    }
}

class Employee2 extends Person {
    String office;
    double salary;
    Date dateHired;

    public Employee2(String name, String address, String phone, String email, String office, double salary) {
        super(name, address, phone, email);
        this.office = office; this.salary = salary; this.dateHired = new Date();
    }

    @Override
    public String toString() {
        return "Employee: " + name;
    }
}

class Faculty extends Employee2 {
    String officeHours;
    String rank;

    public Faculty(String name, String address, String phone, String email, String office, double salary, String officeHours, String rank) {
        super(name, address, phone, email, office, salary);
        this.officeHours = officeHours; this.rank = rank;
    }

    @Override
    public String toString() {
        return "Faculty: " + name;
    }
}

class Staff extends Employee2 {
    String title;

    public Staff(String name, String address, String phone, String email, String office, double salary, String title) {
        super(name, address, phone, email, office, salary);
        this.title = title;
    }

    @Override
    public String toString() {
        return "Staff: " + name;
    }
}

class TestPerson {
    public static void main(String[] args) {
        Person p = new Person("Ali", "Cairo", "0100", "ali@mail.com");
        Student s = new Student("Sara", "Giza", "0111", "sara@mail.com", Student.SENIOR);
        Employee2 e = new Employee2("Omar", "Alex", "0122", "omar@mail.com", "Office 1", 7000);
        Faculty f = new Faculty("Dr. Mona", "Cairo", "0105", "mona@mail.com", "Office 2", 12000, "9-12", "Professor");
        Staff st = new Staff("Ahmed", "Cairo", "0106", "ahmed@mail.com", "Office 3", 5000, "Administrator");

        System.out.println(p);
        System.out.println(s);
        System.out.println(e);
        System.out.println(f);
        System.out.println(st);
    }
}
