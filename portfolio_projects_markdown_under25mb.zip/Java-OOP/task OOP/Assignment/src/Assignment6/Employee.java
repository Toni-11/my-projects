package Assignment6;

public class Employee {
    private int id;
    private double salary;

    public Employee(int id, double salary) {
        this.id = id;
        this.salary = salary;
    }

    public void work() {
        System.out.println("Working as Employee");
    }

    public double getSalary() {
        return salary;
    }
}

class HRManager extends Employee {
    public HRManager(int id, double salary) {
        super(id, salary);
    }

    @Override
    public void work() {
        System.out.println("Managing Employee");
    }

    public void addEmployee() {
        System.out.println("Employee added!");
    }

    public static void main(String[] args) {
        Employee e = new Employee(1, 5000);
        HRManager hr = new HRManager(2, 10000);

        e.work();
        hr.work();
        hr.addEmployee();

        System.out.println("Employee salary = " + e.getSalary());
        System.out.println("HR salary = " + hr.getSalary());
    }
}
