package Assignment6;

public class Vehicle {
    String make, model, fuelType;
    int year;
    double fuelEfficiency;

    public Vehicle(String make, String model, int year, String fuelType, double fuelEfficiency) {
        this.make = make; this.model = model; this.year = year;
        this.fuelType = fuelType; this.fuelEfficiency = fuelEfficiency;
    }

    public double calculateFuelEfficiency() { return fuelEfficiency; }
    public double distanceTraveled() { return fuelEfficiency * fuelEfficiency; }
    public int getMaxSpeed() { return 0; }
}

class Truck extends Vehicle {
    double cargoCapacity;

    public Truck(String make, String model, int year, String fuelType, double fuelEfficiency, double cargoCapacity) {
        super(make, model, year, fuelType, fuelEfficiency);
        this.cargoCapacity = cargoCapacity;
    }

    @Override
    public double calculateFuelEfficiency() {
        return fuelEfficiency * (1.0 / (1 + (cargoCapacity / 1000)));
    }

    @Override
    public double distanceTraveled() {
        return calculateFuelEfficiency() * fuelEfficiency;
    }

    @Override
    public int getMaxSpeed() { return 80; }
}

class Motorcycle extends Vehicle {
    double engineDisplacement;

    public Motorcycle(String make, String model, int year, String fuelType, double fuelEfficiency, double engineDisplacement) {
        super(make, model, year, fuelType, fuelEfficiency);
        this.engineDisplacement = engineDisplacement;
    }

    @Override
    public double calculateFuelEfficiency() {
        return fuelEfficiency * (1.0 / (1 + (engineDisplacement / 1000)));
    }

    @Override
    public double distanceTraveled() {
        return calculateFuelEfficiency() * fuelEfficiency;
    }

    @Override
    public int getMaxSpeed() { return 100; }
}

class TestVehicle {
    public static void main(String[] args) {
        Truck t = new Truck("Volvo", "X1", 2020, "Diesel", 15, 2000);
        Motorcycle m = new Motorcycle("Yamaha", "R1", 2021, "Petrol", 25, 600);

        System.out.println("Truck: FuelEff=" + t.calculateFuelEfficiency() + ", Distance=" + t.distanceTraveled() + ", MaxSpeed=" + t.getMaxSpeed());
        System.out.println("Motorcycle: FuelEff=" + m.calculateFuelEfficiency() + ", Distance=" + m.distanceTraveled() + ", MaxSpeed=" + m.getMaxSpeed());
    }
}
