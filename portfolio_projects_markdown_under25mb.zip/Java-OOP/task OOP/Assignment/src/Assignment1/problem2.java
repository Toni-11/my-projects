package Assignment1;

public class problem2 {
    public static void main(String[] args) {
        System.out.println("   A");
        System.out.println(" A   A");
        System.out.println("A A A A");
        System.out.println("A     A");
    }
}