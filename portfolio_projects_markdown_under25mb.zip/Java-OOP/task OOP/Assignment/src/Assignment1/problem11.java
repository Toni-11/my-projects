package Assignment1;

import java.util.Scanner;


public class problem11 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Balance: ");
        double balance = input.nextDouble();
        System.out.print("Enter Annual_Interest_Rate (%): ");
        double annualRate = input.nextDouble();

        double interest = balance * (annualRate / 1200);
        System.out.printf("Interest for next month = %.2f%n" , interest);
    }
}
