package Assignment1;

import java.util.Scanner;

public class problem9 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter amount of water in kilograms: ");
        double M = input.nextDouble();
        System.out.print("Enter initial temperature in celsius: ");
        double initialTemp = input.nextDouble();
        System.out.print("Enter final temperature in celsius: ");
        double finalTemp = input.nextDouble();

        double Q = M * (finalTemp - initialTemp) * 4184;
        System.out.println("The Energy needed is = " + Q + " joules");
    }
}
