package Assignment1;

import java.util.Scanner;

public class problem12 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter investment amount: ");
        double investmentAmount = input.nextDouble();
        System.out.print("Enter annual interest rate (%): ");
        double annualRate = input.nextDouble();
        System.out.print("Enter number of years: ");
        int years = input.nextInt();

        double monthlyRate = annualRate / 1200;
        double futureInvestmentValue = investmentAmount * Math.pow(1 + monthlyRate, years * 12);

        System.out.printf("Future investment value = %.2f%n" , futureInvestmentValue);
    }
}
