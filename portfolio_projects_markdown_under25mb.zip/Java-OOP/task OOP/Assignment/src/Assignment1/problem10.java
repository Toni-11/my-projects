package Assignment1;

import java.util.Scanner;

public class problem10 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Take_off speed (m/s): ");
        double v = input.nextDouble();
        System.out.print("Enter acceleration (m/s^2): ");
        double a = input.nextDouble();

        double length = (v * v) / (2 * a);
        System.out.println("The Minimum runway length is = " + length);
    }
}
