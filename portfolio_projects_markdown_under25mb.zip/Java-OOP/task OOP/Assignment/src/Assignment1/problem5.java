package Assignment1;

public class problem5 {
    public static void main(String[] args) {
        double kilometers = 14;
        double miles = kilometers / 1.6;
        double timeHours = (45 * 60 + 30) / 3600.0;
        double speed = miles / timeHours;

        System.out.printf("Average speed in miles/hour = %.3f%n" , speed);
    }
}
