package Assignment1;

import java.util.Scanner;

public class problem7 {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter Number by feet: ");
    double feet = input.nextDouble();
    double meters = feet * 0.305;
    System.out.println("The Number in Meters = " + meters);
}
}
