package Assignment1;

import java.io.PrintStream;

public class problem4 {
    public static void main(String[] args) {
        double r = 5.5;
        double pi = Math.PI;
        double perimeter = 2 * r * pi;
        double area = r * r * pi;
        System.out.println("Radius = "+r);
        System.out.printf("Perimeter = %.4f%n" , perimeter);
        System.out.printf("Area = %.4f%n" , area);
    }

}
