package Assignment4;

public class TV {
    private int channel;
    private int volume;
    private boolean on;

    public TV(int channel, int volume) {
        this.channel = channel;
        this.volume = volume;
        this.on = false;
    }

    public void turnOn() { on = true; }
    public void turnOff() { on = false; }

    public void channelUp() { if (on && channel < 120) channel++; }
    public void channelDown() { if (on && channel > 1) channel--; }

    public void volumeUp() { if (on && volume < 7) volume++; }
    public void volumeDown() { if (on && volume > 1) volume--; }

    public int getChannel() { return channel; }
    public int getVolume() { return volume; }

    public static void main(String[] args) {
        TV tv1 = new TV(4, 6);
        TV tv2 = new TV(55, 3);

        tv1.turnOn();
        tv2.turnOn();

        System.out.println("TV1: channel=" + tv1.getChannel() + ", volume=" + tv1.getVolume());
        System.out.println("TV2: channel=" + tv2.getChannel() + ", volume=" + tv2.getVolume());
    }
}
