package Assignment4;

public class Square {
    private double side_length;

    public Square(double side_length) {
        this.side_length = side_length;
    }

    public double calculateArea() {
        return side_length * side_length;
    }

    public double calculatePerimeter() {
        return 4 * side_length;
    }

    public double getSideLength() { return side_length; }

    public static void main(String[] args) {
        Square s1 = new Square(4);
        Square s2 = new Square(8);

        System.out.println("Square 1: side=" + s1.getSideLength() +
                ", area=" + s1.calculateArea() + ", perimeter=" + s1.calculatePerimeter());

        System.out.println("Square 2: side=" + s2.getSideLength() +
                ", area=" + s2.calculateArea() + ", perimeter=" + s2.calculatePerimeter());
    }
}
