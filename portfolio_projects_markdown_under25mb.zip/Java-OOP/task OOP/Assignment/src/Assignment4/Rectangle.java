package Assignment4;

public class Rectangle {
    private double width;
    private double height;

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public double calculateArea() {
        return width * height;
    }

    public double calculatePerimeter() {
        return 2 * (width + height);
    }

    public double getWidth() { return width; }
    public double getHeight() { return height; }

    public static void main(String[] args) {
        Rectangle r1 = new Rectangle(4, 40);
        Rectangle r2 = new Rectangle(3.5, 35.9);

        System.out.println("Rectangle 1: width=" + r1.getWidth() + ", height=" + r1.getHeight() +
                ", area=" + r1.calculateArea() + ", perimeter=" + r1.calculatePerimeter());

        System.out.println("Rectangle 2: width=" + r2.getWidth() + ", height=" + r2.getHeight() +
                ", area=" + r2.calculateArea() + ", perimeter=" + r2.calculatePerimeter());
    }
}
