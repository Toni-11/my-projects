package Assignment2;

public class problem2 {
    public static double powFun(double num1, double num2) {

        return Math.pow(num1, num2);
    }

    public static void main(String[] args) {
        double num1 = 5.2;
        double num2 = 2;
        System.out.println(num1+" ^ " +num2+"= "+ powFun(num1, num2));
    }
}
