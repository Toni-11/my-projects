package Assignment2;

public class problem6 {
    public static void main(String[] args) {
        int[] arr = {5, 6, 8, 1, 7};
        double sum = 0;
        System.out.print("The Average of {");
        for (int num : arr) {
            sum += num;
            System.out.print(num+" , ");
        }
        System.out.print("}");
        double average = sum / arr.length;
        System.out.println(" = " + average);
    }
}
