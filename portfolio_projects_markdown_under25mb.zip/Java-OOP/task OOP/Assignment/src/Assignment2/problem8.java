package Assignment2;

public class problem8 {
    public static int maxFun(int[] arr) {
        int max = arr[0];
        for (int num : arr) {
            if (num > max)
                max = num;
        }
        return max;
    }

    public static void main(String[] args) {
        int[] arr = {5,6,8,1,7};
        System.out.println("Maximum value = " + maxFun(arr));
    }
}
