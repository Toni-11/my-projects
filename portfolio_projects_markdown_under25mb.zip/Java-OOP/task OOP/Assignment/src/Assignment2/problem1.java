package Assignment2;

import java.util.Scanner;

public class problem1 {

    public static double disFun(double amount) {
        double discount = (amount > 1000) ? 0.15 : 0.05;
        return amount - (amount * discount);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter Purchase Amount: ");
         double amount = input.nextDouble();
        System.out.println("Original Price: "+amount);
        System.out.println("Amount after discount = " + disFun(amount));
    }
}
