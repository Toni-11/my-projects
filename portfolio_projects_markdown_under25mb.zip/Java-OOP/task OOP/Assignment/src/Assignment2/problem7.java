package Assignment2;

import java.util.Arrays;

public class problem7 {
    public static void main(String[] args) {
        int[] arr = {5,6,8,1,7,4,3,9,2,12};
        int evenProduct = 1;
        int oddProduct = 1;

        for (int num : arr) {

            if (num % 2 == 0)
                evenProduct *= num;
            else
                oddProduct *= num;

        }
        System.out.print("Multiplcation even and odd number separately for "+ Arrays.toString(arr));
        System.out.println("\n");
        System.out.println("Even product = " + evenProduct);
        System.out.println("Odd product = " + oddProduct);
    }
}
