package Assignment2;

public class problem4 {
    public static void gradeFun(int prog, int discrete, int math, int linear, int physics) {
        double percentage = (prog + discrete + math + linear + physics) / 5.0;
        String grade;

        if (percentage >= 90) grade = "A";
        else if (percentage >= 80) grade = "B";
        else if (percentage >= 70) grade = "C";
        else if (percentage >= 60) grade = "D";
        else if (percentage >= 50) grade = "E";
        else grade = "F";

        System.out.println("Percentage = " + percentage + "%");
        System.out.println("Grade = " + grade);
    }

    public static void main(String[] args) {

        gradeFun(85, 90, 78, 88, 92);
    }
}
