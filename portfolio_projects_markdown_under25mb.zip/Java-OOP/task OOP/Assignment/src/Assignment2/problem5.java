package Assignment2;

public class problem5 {
    public static float distance(float x1, float y1, float x2, float y2) {
        return (float)Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }

    public static void main(String[] args) {

        System.out.println("Distance = " + distance(1.0f, 2.0f, 4.0f, 6.0f));
    }
}
