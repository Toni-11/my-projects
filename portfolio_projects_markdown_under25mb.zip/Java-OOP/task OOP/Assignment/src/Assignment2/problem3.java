package Assignment2;

public class problem3 {
    public static void multTable(int num) {
        System.out.println("Multiplication table of " + num);
        for (int i = 1; i <= 10; i++) {
            System.out.println(num + " x " + i + " = " + (num * i));
        }
    }

    public static void main(String[] args) {
        int fixedNumber = 5;
        multTable(fixedNumber);
    }
}
