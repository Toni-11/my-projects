# Document

Job Matching System

Team Members

Instructor / Salma Maged

Supervisor / TA

___________________Dr. Amr Ibrahim _______________

1. Introduction

The Job Matching System is an online platform designed to connect job seekers with employers through an intelligent and automated matching mechanism. The system addresses the inefficiencies of traditional recruitment by analyzing user skills and job requirements to recommend suitable opportunities with a calculated matching percentage. This document describes the software requirements for the Job Matching System, providing a complete overview of the system's purpose, scope, functionality, and constraints.

1.1 Purpose

The purpose of this Software Requirements Specification (SRS) document is to provide a detailed description of the Job Matching System. It defines the functional and non-functional requirements of the system and serves as a reference for developers, designers, testers, and stakeholders involved in the development process. The document ensures a shared understanding of system expectations and guides the design and implementation phases.

1.2 Scope

The Job Matching System is a web-based application that facilitates the recruitment process by enabling job seekers to create profiles, list their skills, and receive job recommendations based on a matching algorithm. Employers can post job listings and review applicant profiles. The system will include a matching engine that calculates the compatibility percentage between a job seeker's skills and a job's requirements. The system is intended for use by three main user categories: Job Seekers, Employers, and Administrators.

Out of scope for the initial release: integration with third-party platforms such as LinkedIn, payment processing, and mobile native applications.

1.3 Definitions

Job Seeker: A registered user who is actively searching for employment opportunities.

Employer: A registered user or organization that posts job vacancies on the platform.

Admin: A system administrator responsible for managing users and monitoring system activity.

Matching Percentage: A calculated score representing the compatibility between a job seeker's skills and a job's required skills.

SRS: Software Requirements Specification — a formal document describing system requirements.

1.4 Overview

This SRS is organized into the following sections: Introduction, Overall Description, User Requirements, Functional Requirements, and Non-Functional Requirements. Each section provides increasing levels of detail about the system. The context diagram below illustrates the interaction between the Job Matching System and its external entities.

Context Diagram

2. Overall Description

This section provides a high-level overview of the Job Matching System, including its architectural perspective, intended user classes, operating environment, and applicable assumptions and constraints.

2.1 System Perspective

The Job Matching System is a standalone web application with potential for future integration with external job portals and professional networking platforms such as LinkedIn. It consists of a front-end user interface accessible via web browsers, a back-end processing engine, and a database for storing user profiles, job listings, and application records. The matching engine operates as a core module that computes compatibility scores between job seekers' skills and job requirements.

2.2 User Classes

Guest: Can browse available job listings and register for an account. No authentication required.

Job Seeker: Can create and manage a personal profile, add skills, search for jobs, view matching percentages, and apply for positions.

Employer: Can post and manage job listings, define required skills, and review applicant profiles.

Admin: Has full system access to manage users, monitor activity, generate reports, and remove inappropriate content.

2.3 Operating Environment

The system will operate in a web-based environment and must support the following:

Web browsers: Google Chrome, Mozilla Firefox, Microsoft Edge, and Safari (latest versions).

Mobile-responsive design compatible with iOS and Android devices.

Server-side environment: Linux-based web server with database support.

Internet connectivity is required for all system operations.

2.4 Assumptions and Constraints

All users must have a valid internet connection to access the system.

Users are assumed to have basic computer literacy.

The system will initially support English language only.

The matching algorithm will be based on keyword matching of skills in the initial release.

The system must comply with applicable data privacy regulations.

3. User RequirementsThis section lists the requirements as described by the users in their own language, focusing on what they need the system to accomplish without specifying technical implementation details.

3.1 Job Seeker Requirements

Create an account and log in to the system securely.

Create a personal profile and add relevant skills.

Update profile information at any time.

View job listings that match their skills.

See the matching percentage for each recommended job.

Apply for jobs directly through the platform.

3.2 Employer Requirements

Create an account and log in to the system.

Post new job opportunities with descriptions and required skills.

Define the skills required for each job posting.

View and review profiles of applicants.

Select suitable candidates from the applicant list.

3.3 Admin Requirements

Manage all user accounts (job seekers, employers).

Monitor system activity and usage.

Remove inappropriate or spam content from the platform.

Generate system reports as needed.

4. Functional Requirements

This section lists the functional requirements in ranked order. Functional requirements describe the possible effects of the software system — that is, what the system must accomplish.

FR1: Create Profile

Description / Action: The system allows a job seeker to create a personal profile containing their educational background and professional skills.

Inputs: Full Name, Educational Qualifications, Skills List.

Source: Job Seeker.

Pre-condition: The user must be registered and logged into the system.

Post-condition: A new profile is created and stored in the system database.

Output: A confirmation message: "Profile created successfully."

FR2: Add / Update Skills

Description / Action: The system allows a job seeker to add new skills or update existing ones in their profile.

Inputs: Skill names (e.g., Python, Java, Data Analysis).

Source: Job Seeker.

Pre-condition: A profile must already exist for the user.

Post-condition: The skills list in the user's profile is updated accordingly.

Output: A confirmation message: "Skills updated successfully."

FR3: Post Job

Description / Action: The system allows an employer to post a new job vacancy, including the job title, description, and required skills.

Inputs: Job Title, Job Description, Required Skills, Application Deadline.

Source: Employer.

Pre-condition: The employer must be registered and logged into the system.

Post-condition: The job listing is published and made visible to job seekers.

Output: A confirmation message: "Job posted successfully."

FR4: Match Jobs

Description / Action: The system automatically matches a job seeker's skills with the requirements of available job listings and calculates a compatibility percentage for each match.

Inputs: Job Seeker's Skills List and Job Requirements from the database.

Source: System (automated process triggered upon search or login).

Pre-condition: The job seeker must have a profile with at least one skill, and job listings must exist in the system.

Post-condition: A ranked list of matching jobs is generated and displayed.

Output: A list of job listings with their corresponding matching percentage scores.

FR5: Apply for Job

Description / Action: The system allows a job seeker to submit an application for a specific job listing.

Inputs: Job ID selected by the user.

Source: Job Seeker.

Pre-condition: The user must be logged in and the selected job must be available and active.

Post-condition: The application is recorded and the employer is notified.

Output: A confirmation message: "Application submitted successfully."

5. Non-Functional Requirements

This section describes the non-functional requirements that specify the quality attributes and operational constraints of the Job Matching System. These requirements define how the system performs its functions rather than what it does.

NFR1: Performance

The system must deliver search results and job match recommendations within a maximum response time of 2 seconds under normal operating conditions. Database queries and the matching algorithm must be optimized to ensure fast processing even with a large number of concurrent users.

NFR2: Usability

The user interface must be intuitive, clean, and easy to navigate for all user types, including those with limited technical experience. The system must follow standard UI/UX design principles and provide clear feedback messages for all user actions. The interface must be accessible to users with disabilities, complying with WCAG 2.1 guidelines where applicable.

NFR3: Reliability

The system must maintain an operational uptime of at least 99% on a monthly basis. It must include automatic error handling and recovery mechanisms to minimize downtime. Regular database backups must be performed to prevent data loss in the event of system failure.

NFR4: Security

All user passwords must be stored using a strong cryptographic hashing algorithm (e.g., bcrypt). Communication between the client and server must be encrypted using HTTPS/TLS protocols. The system must implement role-based access control (RBAC) to ensure that users can only access features and data appropriate to their role. The system must also be protected against common web vulnerabilities such as SQL injection and cross-site scripting (XSS).

NFR5: Scalability

The system architecture must be designed to handle a growing number of users and data without significant degradation in performance. The system should be capable of supporting a minimum of 10,000 concurrent users and should allow for horizontal scaling of server resources to accommodate future growth.

NFR6: Compatibility

The system must function correctly on all major modern web browsers, including Google Chrome, Mozilla Firefox, Microsoft Edge, and Safari. The user interface must be fully responsive and compatible with mobile devices running iOS and Android operating systems. The system should not require any additional plugins or software installations on the client side.

NFR7: Maintainability

The system codebase must follow clean coding standards and be thoroughly documented to facilitate future updates and maintenance. The architecture must support modular design so that individual components can be updated or replaced without affecting the entire system. A version control system must be used throughout the development lifecycle to track changes and manage releases.

6- UML Diagrams

6.1. Use Case Diagram

6.1. Use Case Diagram

6.1. Use Case Diagram

6.1.Use Case Diagram

6.1. Use Case Diagram

6.2. Sequence Diagram

6.2. Sequence Diagram

6.2. Sequence Diagram

6.2. Sequence Diagram

6.3. Activity Diagram

6.4. Class Diagram

6.5. DFD Level_0 Diagram

6.5. DFD Level_1 Diagram

6.5. DFD Level_2 Diagram

6.5. DFD Level_3 Diagram

6.5. DFD Level_4 Diagram

6.5. DFD Level_5 Diagram

Name | ID
Verginia Yosry | 245511
Alaa Ehab | 245111
Martina Maged | 245606
Youstina Zakariya | 245189
Michael Ibrahim Luka | 245528
