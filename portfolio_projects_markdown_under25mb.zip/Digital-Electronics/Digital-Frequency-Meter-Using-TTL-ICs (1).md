# PDF Content

## Page 1

Digital Frequency Meter Using 
TTL ICs
Supervised by:
ENG.Meral Helmy
Created by:
Martin Romany [245531] 1.
Michael Ibrahim [245528] 2.
Antton Mikhael [245455] 3.

## Page 2

Project Overview:
This project implements a digital frequency meter that measures the frequency of an input signal by counting the number of 
pulses within a fixed time interval. The measured frequency is displayed in decimal form using seven-segment displays.

## Page 3

Objective:
Measure the frequency of a 
digital input signal 
accurately
Display the frequency value 
clearly using digital displays
Apply digital electronics 
concepts using TTL 
integrated circuits

## Page 4

Working Principle :
The frequency meter operates by allowing the input signal to pass through a gating circuit for a fixed duration (typically 1 second). 
During this gate time, the signal pulses are counted using BCD up counters. After the gate time ends, counting stops and the final 
count represents the frequency in Hertz (Hz).

## Page 5

Main Components Used:
74192 (BCD Up/Down Counters): Used to count the number of input pulses in decimal format.
7447 (BCD to 7-Segment Decoder): Converts the BCD output of the counters into signals suitable for seven-segment displays.
74F04 (NOT Gates): Used for signal inversion, timing control, and pulse shaping.
74F08 (AND Gate): Used to control the gate time.
Seven-Segment Displays (Common Anode): Used to display the measured frequency value.

## Page 6

Block Diagram Description :
The system consists of four main blocks:
01
Input signal conditioning
02
Gate time control circuit
03
Counting circuit using BCD counters
04
Display circuit using seven-segment displays

## Page 7

Accuracy Considerations
Accuracy depends on the stability of the gate time
Noise in the input signal may affect counting
Increasing the gate time improves measurement resolution

## Page 8

Applications:
Frequency measurement 
in communication systems
Digital electronics 
laboratories
Signal testing and analysis

## Page 9

Conclusion :
The digital frequency meter successfully measures and displays the 
frequency of an input signal using basic digital logic components. This 
project demonstrates practical implementation of counters, logic gates, 
and display decoding in digital electronics.
