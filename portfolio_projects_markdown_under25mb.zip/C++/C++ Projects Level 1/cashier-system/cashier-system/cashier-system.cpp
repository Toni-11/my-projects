#include <iostream>
#include <string>

using namespace std;

int main()
{
    string item1 = "", item2 = "", item3 = "", item4 = "", item5 = "";
    double price1 = 0, price2 = 0, price3 = 0, price4 = 0, price5 = 0;
    int itemCount = 0;
    int choice = 0;
    int i = 0;

    do
    {
        cout << "\nCashier System Menu:\n";
        cout << "1. Add Item\n";
        cout << "2. Display Items\n";
        cout << "3. Payment\n";
        cout << "4. Exit\n";
        cout << "Enter a number: ";
        cin >> choice;

        while (choice < 1 || choice > 4)
        {
            cout << "Your Choice " << choice << " Is Not Valid\n";
            cout << "Please Choose an option (1-4): ";
            cin >> choice;
            i++;
        }

        if (choice == 1)
        {
            if (itemCount >= 5)
            {
                cout << "Cannot add more items. Maximum limit (5)." << endl;
            }
            else
            {
                string itemName = "";
                double itemPrice = 0;

                cout << "Enter item name: ";
                cin >> itemName;
                cout << "Enter item price: ";
                cin >> itemPrice;

                if (itemCount == 0)
                {
                    item1 = itemName;
                    price1 = itemPrice;
                }
                else if (itemCount == 1)
                {
                    item2 = itemName;
                    price2 = itemPrice;
                }
                else if (itemCount == 2)
                {
                    item3 = itemName;
                    price3 = itemPrice;
                }
                else if (itemCount == 3)
                {
                    item4 = itemName;
                    price4 = itemPrice;
                }
                else if (itemCount == 4)
                {
                    item5 = itemName;
                    price5 = itemPrice;
                }

                cout << "Added: " << itemName << " - $" << itemPrice << endl;
                itemCount++;
            }
        }
        else if (choice == 2)
        {
            cout << "\nItems in the cart:\n";
            double total = 0.0;

            if (itemCount >= 1)
            {
                cout << item1 << " - $" << price1 << endl;
                total += price1;
            }
            if (itemCount >= 2)
            {
                cout << item2 << " - $" << price2 << endl;
                total += price2;
            }
            if (itemCount >= 3)
            {
                cout << item3 << " - $" << price3 << endl;
                total += price3;
            }
            if (itemCount >= 4)
            {
                cout << item4 << " - $" << price4 << endl;
                total += price4;
            }
            if (itemCount >= 5)
            {
                cout << item5 << " - $" << price5 << endl;
                total += price5;
            }
            cout << "Total: $" << total << endl;
        }
        else if (choice == 3)
        {
            double total = 0.0;

            if (itemCount >= 1)
                total += price1;
            if (itemCount >= 2)
                total += price2;
            if (itemCount >= 3)
                total += price3;
            if (itemCount >= 4)
                total += price4;
            if (itemCount >= 5)
                total += price5;

            double payment = 0;
            cout << "Enter payment amount: ";
            cin >> payment;

            if (payment < total)
            {
                cout << "Error payment. Please pay at least $" << total << endl;
            }
            else
            {
                double change = payment - total;
                cout << "The Payment = $" << payment << endl;
                cout << "The Cost = $" << total << endl;
                cout << "Change = $" << change << endl;
            }
        }
        else if (choice == 4)
        {
            cout << "Exiting the system. Thank you for shopping!\n";
        }
    } while (choice != 4);

    return 0;
}