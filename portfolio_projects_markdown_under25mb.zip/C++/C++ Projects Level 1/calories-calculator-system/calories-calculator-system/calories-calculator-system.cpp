#include <iostream>
#include <map>
using namespace std;

int main() {
    // Simple database of foods and their calories
    map<string, int> foodCalories = {
        {"Apple", 52},     // per 100 grams
        {"Banana", 89},
        {"Bread", 265},
        {"Rice", 130},
        {"Meat", 250},
        {"Fish", 206},
        {"Egg", 155}
    };

    string foodItem;
    int quantity, totalCalories = 0;
    char choice;

    cout << "Welcome to the Calorie Calculator Program!\n";

    do {
        cout << "\nChoose a food from the following list:\n";
        for (auto& item : foodCalories) {
            cout << "- " << item.first << " (" << item.second << " cal/100 grams)\n";
        }

        cout << "\nEnter the food name: ";
        cin >> foodItem;

        // Check if the food exists in the list
        if (foodCalories.find(foodItem) != foodCalories.end()) {
            cout << "Enter the quantity (in grams): ";
            cin >> quantity;

            // Calculate calories
            totalCalories += (foodCalories[foodItem] * quantity) / 100;
            cout << "Added! Total calories now: " << totalCalories << " cal.\n";
        }
        else {
            cout << "Food not found in the list!\n";
        }

        cout << "Do you want to add more? (y/n): ";
        cin >> choice;

    } while (choice == 'y' || choice == 'Y');

    cout << "\nTotal calories consumed: " << totalCalories << " cal.\n";
    cout << "Thank you for using the program!\n";

    return 0;
}