# PDF Content

## Page 1

Number Guessing Game in C++
A simple interactive game where users guess a randomly generated 
number.
Created by : Kerolos Hanaey 
ID : 245454

## Page 2

Program Idea
Random Number
Generated between 1 and 100
User Interaction
User inputs guesses sequentially
Hints Logic
Too far: > 25 difference
Very close: f 25 difference
You win: exact match

## Page 3

Inputs
User Input
Number between 1 and 100
Input V alidation
Rejects numbers outside valid range

## Page 4

Outputs
Correct Guess
"The Guess is True, you win!" message
F ar Guess
"The Guess is false, Too far."
Close Guess
"The Guess is false, Very close."
Invalid Input
Prompts for retry if out of range

## Page 5

How It Works (Logic Flow)
Generate Number
rand() % 100 + 1
Get User Guess
Input from 1 to 100
Validate Input
Check range, reprompt if invalid
Compare Guess
Equal ³ Win
Difference > 25 ³ Too Far
Else ³ Very Close

## Page 6

Conclusion
Randomness
Using rand() and srand() functions
Input V alidation
Ensuring valid user guesses
Conditional Logic
Hints and control flow using if-else
Control Structures
Foundations of loops and branching in C++
