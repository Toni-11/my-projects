# PDF Content

## Page 1

C++ Programming Project: 
Cashier System
Introduction to building a simple cashier system using C++ programming.
Created by: Antton Mikhael
ID : 245455

## Page 2

Project Idea
Build a cashier system
Using C++ and arrays
Features
Product management, price 
calculation, payment 
processing
Explore
Program structure and array data storage

## Page 3

Project Objective
Practical Application
Reinforce core C++ concepts
Supports
Procedural programming and 
data handling
Audience
Beginner computer science students

## Page 4

Project Concept
Add products (max 5)
Display products with prices
Calculate total price
Process payment and calculate change
Exit system

## Page 5

Project Goal
Key Features
Add up to 5 products
Display products and prices
Calculate total price
Payment & Exit
Process payment and compute balance
Option to exit system
Learn arrays and I/O in C++

## Page 6

Tools Used
Programming Language
C++ for flexibility and 
procedural support
Development 
Environment
Visual Studio and 
Code::Blocks for coding and 
debugging
Programming Style
Procedural approach using arrays

## Page 7

Program Structure
Arrays
Store product names in items[5], prices 
in prices[5]
Variables
itemCount tracks number of products 
added
Main Menu
Options: Add product, display list, 
process payment, exit

## Page 8

Adding a Product
Request product name
cout << "Enter item name:"
Receive input
cin >> itemName;
Store data
items[itemCount] = itemName; 
prices[itemCount] = itemPrice;

## Page 9

Displaying Products & Payment
1
Display products
Loop through items and prices arrays
2
Calculate total
Sum prices in a loop
3
Process payment
Input payment, calculate and show change

## Page 10

System Testing Experience
Product Entry
Entered product names and 
prices successfully
Product Display
Displayed list and calculated 
total accurately
Payment & Change
Processed payment and calculated correct balance
