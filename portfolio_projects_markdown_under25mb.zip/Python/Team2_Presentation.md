# Presentation

## Slide 1

🏠

House Price Prediction

Machine Learning Pipeline — Ames Housing Dataset

Team 2

79

Features

2,930

Records

0.92+

Best R²

## Slide 2

Project Overview

🎯  Objective

Predict residential property sale prices using a full supervised ML pipeline on the Ames, Iowa housing dataset.

📦  Dataset

2,930 houses with 79 features — physical dimensions, quality scores, location, and condition attributes.

🔬  Approach

EDA → Data Cleaning → Feature Engineering → Model Training → Evaluation → Deployment via Streamlit.

🏆  Deliverable

A Streamlit app ('Enterprise Valuation Engine') supporting both batch CSV upload and interactive single-property prediction.

## Slide 3

Dataset & Exploratory Data Analysis

EDA Highlights

📊

Univariate Analysis — SalePrice histogram (right-skewed) and boxplot to detect outliers

🔗

Bivariate Analysis — Year Built vs SalePrice (line), Gr Liv Area vs SalePrice (scatter)

🗺️

Categorical Analysis — Neighborhood vs SalePrice barplot; House Style countplot

🌡️

Multivariate — Correlation heatmap across all numeric features (16×12 figure)

Top Correlated Features

Overall Qual

Strongest predictor

Gr Liv Area

Above-grade living sq.ft

Garage Area

Garage & # of cars

Total Bsmt SF

Basement square footage

Year Built

Newer = higher price

Kitchen Qual

Kitchen finish grade

## Slide 4

Data Preprocessing Pipeline

01

Drop Irrelevant Cols

Remove 'Order' & 'PID' — ID-only, no predictive value

02

Remove Duplicates

Deduplicate rows & reset index for clean data

03

Handle Missing Values

Drop rows with <2% NaN cols; median-impute numeric; mode-impute categorical

04

Encode Categoricals

20 ordinal columns → OrdinalEncoder with domain-ordered categories

05

One-Hot Encode

Remaining nominal columns → pd.get_dummies (drop_first=True)

06

Train/Test Split

80% train / 20% test — random_state=42 for reproducibility

07

Feature Scaling

StandardScaler on all features — required for Ridge & gradient methods

## Slide 5

Model Training & Evaluation

R² Score by Model (higher = better)

Performance Summary

Model

R²

MAE

RMSE

Ridge

0.85

~$17k

~$26k

Dec. Tree

0.83

~$18k

~$28k

Rand. Forest

0.90

~$15k

~$22k

HGB ⭐

0.92

~$14k

~$20k

XGBoost ⭐

0.92

~$14k

~$20k

⭐ Best models selected by R² — saved to best_model.joblib

## Slide 6

🏢 Enterprise Valuation Engine (Streamlit App)

📂  Batch Processing Mode

Upload any CSV / Excel dataset

Auto-runs the full preprocessing pipeline

Displays avg. valuation & total properties

Shows valuation trend line chart

One-click download of enriched results CSV

🎛️  Interactive Smart Form Mode

Sliders for Gr Liv Area, Basement, Garage sqft

Dropdowns for quality: Exter, Kitchen, Bsmt

Select Neighborhood, Year Built, Garage Cars

Central Air system radio button

Instant price estimate with ±MAE range

Pipeline cached with @st.cache_resource — no retraining on page reload   |   MAE bound: ±$13,945.90

## Slide 7

Key Takeaways

✅  Hist Gradient Boosting & XGBoost achieved R² ≈ 0.92 — excellent predictive accuracy

✅  79-feature Ames dataset required careful ordinal encoding (20 columns) and median imputation

✅  StandardScaler applied before training — critical for Ridge and gradient-based models

✅  Deployed as a full Streamlit app with batch + interactive modes for real-world usability

✅  Best model persisted with joblib — production-ready inference without retraining

Team 2  ·  House Price Prediction  ·  Ames Housing Dataset
