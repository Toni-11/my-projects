# Presentation

## Slide 2

نظام إدارة الدرجات الأكاديمية

Academic Grades Management System

بناء نظام Python متكامل لمعالجة البيانات الأكاديمية
باستخدام القوائم ثنائية الأبعاد (2D Lists)
والتحليل الإحصائي المتقدم

Python

2D Lists

Statistics

Data Processing

Python Academic Project  •  2D List Data Structure  •  Statistical Analysis

## Slide 3

Project Overview  |  نظرة عامة على المشروع

📥

Input & Validation

الإدخال والتحقق

Secure data entry with while loop protection against invalid inputs

إدخال آمن للبيانات مع حماية ضد المدخلات الخاطئة

🗂️

2D Data Structure

هيكل البيانات ثنائي الأبعاد

Nested Lists to store grades for multiple students and subjects

قوائم متداخلة لتخزين درجات الطلاب والمواد

📊

Statistical Analysis

التحليل الإحصائي

Extract averages, percentages, top and bottom performers

استخراج المتوسطات والنسب والمتفوقين والضعاف

⚡  Built with pure Python — no external libraries required  |  مبني بـ Python خالص بدون مكتبات خارجية

## Slide 4

Phase 1

Input & Validation  |  إعداد المدخلات وتأمين البيانات

● ● ●   input_validation.py

while True:
    num_students = 
int(input(
        'Enter number of students: '
))
    num_subjects = 
int(input(
        'Enter number of subjects: '
))
    
if num_students > 0 and num_subjects > 0:
        
break
    
print(
        'Invalid! Values must be > 0'
)

Infinite Loop Guard

حلقة تكرار لا نهائية  |  while True prevents program from continuing without valid data

Type Safety

أمان النوع  |  int() conversion ensures only numeric values are accepted

Logical Validation

التحقق المنطقي  |  Values must be > 0 to prevent ZeroDivisionError later

Clean Exit

خروج نظيف  |  break exits only after successful validation

## Slide 5

Phase 2

Building the 2D Array  |  بناء مصفوفة الدرجات

2D List Structure

Subj 1

Subj 2

Subj 3

Std 1

85

90

78

Std 2

92

88

95

Std 3

76

82

89

students_grades[i][j]

● ● ●   build_2d_array.py

students_grades = []

for i in range(num_students):
    student_marks = []
    
for j in range(num_subjects):
        mark = 
float(input(f'Grade for Subj {j+1}: '))
        if 0 <= mark <= 100:
            student_marks.
append(mark)
    students_grades.
append(student_marks)

Nested Lists
قوائم متداخلة

Nested Loops
حلقات متداخلة

float() Precision
دقة العمليات

Range Validation
فلتر النطاق

## Slide 6

Statistical Analysis  |  التحليل الإحصائي

Phase 3  —  Individual Results  |  النتائج الفردية

total_possible = num_subjects * 100

for i in range(num_students):
    student_sum = sum(students_grades[i])
    percentage = (
        student_sum / total_possible
    ) * 
100
    
print(f'Student {i+1}:\n'
        f'Total={student_sum}\n'
        f'% = {percentage:
.2f}%')

∑  sum() built-in function

%  Percentage = (total / max) × 100

.2f  2 decimal places formatting

Phase 4  —  Subject Analysis  |  تحليل المواد

for j in range(num_subjects):
    # List Comprehension
    subject_grades = [
        students_grades[i][j]
        
for i in range(num_students)
    ]

    max_grade = 
max(subject_grades)
    min_grade = 
min(subject_grades)
    avg_grade = 
sum(subject_grades)
                 / num_students

[]  List Comprehension — column extraction

↑↓  max() & min() for top/bottom performers

x̄  Average reveals difficulty level

## Slide 7

Technical Notes & Summary  |  ملاحظات تقنية وخلاصة

⚙️  Technical Notes  |  ملاحظات تقنية

float() for Accuracy

استخدام float() للدقة  •  Decimal grades like 87.5 are handled correctly without rounding errors

List of Lists Memory

قائمة من القوائم  •  The most efficient Python structure for tabular data without external libs

index() for Top Performers

index() لتحديد المتفوقين  •  Links max grade back to a student number automatically

No External Libraries

بدون مكتبات خارجية  •  Uses only Python built-ins: sum(), max(), min(), input(), print()

📊  Statistical Outputs  |  المخرجات الإحصائية

Per Student  |  لكل طالب

Total score

Percentage %

Pass / Fail

Per Subject  |  لكل مادة

Average grade

Highest score + student

Lowest score + student

Insights  |  رؤى

Difficulty indicator

Students needing support

Top performers

## Slide 8

✅

Project Complete!

المشروع مكتمل!

4

Phases
مراحل

2D

List Structure
هيكل البيانات

100%

Pure Python
بايثون خالص

∞

Scalable
قابل للتوسع

Built with Python  •  No External Libraries  •  Academic Grade System
