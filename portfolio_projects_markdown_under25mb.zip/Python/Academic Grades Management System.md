# Document

Academic Grades Management System

Slide 1 — Title

English

Good morning, today I will present my project which is called Academic Grades Management System built using Python.

The purpose of this project is to design a simple academic system that can store students’ grades, process them, and analyze the results using Python programming.

In many educational environments, grades are still processed manually or using simple spreadsheets. This project demonstrates how programming can help automate this process and make it more organized and efficient.

The system allows us to input grades for multiple students and subjects, store the data in a structured way, and then perform statistical analysis to understand students' performance.

الترجمة بالعامية

صباح الخير، النهاردة هقدم المشروع بتاعي واسمه
نظام إدارة الدرجات الأكاديمية باستخدام بايثون.

هدف المشروع إننا نعمل سيستم بسيط يقدر يخزن درجات الطلبة ويعالجها ويحلل النتائج باستخدام لغة بايثون.

في أماكن تعليم كتير إدارة الدرجات بتكون بشكل يدوي أو باستخدام جداول بسيطة، وده ممكن يسبب أخطاء.

المشروع ده بيوضح إزاي البرمجة ممكن تساعد في تنظيم البيانات وتحليلها بطريقة أسرع وأدق.

Slide 2 — Project Overview

English

The main problem this project tries to solve is the difficulty of managing academic grades efficiently.

When dealing with many students and multiple subjects, calculating totals, percentages, and averages manually can take time and may lead to mistakes.

Therefore, the goal of this system is to automate this process using Python.

The system performs three main tasks:

Collecting grades from the user

Storing them in a structured data format

Performing statistical analysis such as totals, averages, and highest or lowest scores.

This makes the system useful for understanding both individual student performance and overall subject performance.

الترجمة بالعامية

المشكلة الأساسية اللي المشروع بيحاول يحلها هي صعوبة إدارة درجات الطلبة بكفاءة.

لما يكون عندنا عدد كبير من الطلبة وعدة مواد، حساب المجموع والنسب والمتوسطات بشكل يدوي بياخد وقت وممكن يحصل فيه أخطاء.

علشان كده الهدف من السيستم إنه يعمل أتمتة للعمليات دي باستخدام بايثون.

السيستم بيعمل 3 حاجات أساسية:

إدخال الدرجات

تخزينها بشكل منظم

تحليلها إحصائياً

وده بيساعدنا نفهم أداء الطلبة ومستوى المواد.

Slide 3 — Technologies Used

English

This project is implemented using Python programming language because Python is simple, readable, and widely used in data processing and analysis.

One of the key data structures used in this project is the 2D List.

A 2D list is essentially a list that contains other lists. This allows us to represent data in a table-like structure, where rows represent students and columns represent subjects.

You might wonder why we used Lists instead of Arrays.

In Python, lists are more flexible than arrays because:

They can dynamically change size.

They are easier to work with.

They do not require predefined memory size.

This makes lists more suitable for storing data when the number of students or subjects can vary.

الترجمة بالعامية

المشروع ده معمول باستخدام لغة بايثون لأنها لغة سهلة القراءة ومناسبة جداً لمعالجة البيانات.

أهم هيكل بيانات استخدمناه هو 2D List.

الـ 2D List هي قائمة جوهها قوائم تانية، وده بيخلينا نقدر نمثل البيانات زي جدول.

الصفوف بتمثل الطلبة
والأعمدة بتمثل المواد.

ممكن حد يسأل: ليه استخدمنا List بدل Array؟

السبب إن الـ List في بايثون:

حجمها ممكن يتغير بسهولة

التعامل معاها أسهل

مش محتاجة نحدد حجمها من الأول

علشان كده كانت أنسب لتخزين درجات الطلبة.

Slide 4 — Input & Validation

English

The first phase of the system is collecting input from the user.

The program asks the user to enter the number of students and the number of subjects.

To make sure the program works correctly, we implemented input validation using a while loop.

The loop continues asking for input until the user enters valid values.

This validation is important because it prevents logical errors later in the program, such as division by zero when calculating averages.

It also ensures that the system only processes meaningful data.

الترجمة بالعامية

أول مرحلة في البرنامج هي إدخال البيانات.

البرنامج بيطلب من المستخدم يدخل:

عدد الطلبة

عدد المواد

علشان نتأكد إن البرنامج يشتغل بشكل صحيح، استخدمنا while loop علشان نتحقق من صحة البيانات.

البرنامج يفضل يطلب الإدخال لحد ما المستخدم يدخل قيمة صحيحة.

وده مهم علشان يمنع أخطاء ممكن تحصل بعد كده في الحسابات.

Slide 5 — 2D List Structure

English

After collecting the input, the program creates a 2D list to store the grades.

Each row in the list represents one student.

Each column represents the grade of a specific subject.

For example, if we have 3 students and 3 subjects, the structure will look like a table with 3 rows and 3 columns.

This structure allows us to easily access grades using indices such as:

students_grades[i][j]

Where:

i represents the student

j represents the subject

This approach makes the program organized and efficient when processing large sets of academic data.

الترجمة بالعامية

بعد ما ناخد البيانات من المستخدم، البرنامج بيعمل 2D List علشان يخزن الدرجات.

كل صف بيمثل طالب
وكل عمود بيمثل مادة.

يعني لو عندنا 3 طلبة و3 مواد، البيانات هتكون شبه جدول.

وبنقدر نوصل لأي درجة باستخدام:

students_grades[i][j]

حيث:
i تمثل الطالب
j تمثل المادة

وده بيسهل التعامل مع البيانات بشكل كبير.

Slide 6 — Student Results

English

Once all grades are stored, the system begins analyzing student performance.

For each student, the program calculates the total score by summing all subject grades.

After calculating the total score, the program calculates the percentage based on the maximum possible score.

This allows us to easily evaluate each student’s academic performance.

The results help identify strong students as well as students who may need academic support.

الترجمة بالعامية

بعد ما الدرجات تتخزن، البرنامج يبدأ يحلل أداء الطلبة.

لكل طالب البرنامج بيحسب المجموع الكلي عن طريق جمع درجات المواد.

بعد كده بيحسب النسبة المئوية على أساس الدرجة الكلية الممكنة.

ده بيساعدنا نعرف مستوى كل طالب بسهولة.

Slide 7 — Subject Analysis

English

In addition to analyzing students, the system also analyzes each subject.

The program extracts grades for each subject and calculates:

The highest score

The lowest score

The average score

This analysis helps understand how difficult a subject is and how students are performing in it.

For example, if the average score is low, it may indicate that the subject is challenging or requires further explanation.

الترجمة بالعامية

البرنامج مش بيحلل الطلبة بس، لكنه كمان بيحلل المواد.

لكل مادة البرنامج بيحسب:

أعلى درجة

أقل درجة

متوسط الدرجات

التحليل ده بيساعدنا نفهم مستوى المادة.

لو المتوسط قليل مثلاً، ممكن ده يدل إن المادة صعبة.

Slide 8 — Conclusion

English

In conclusion, this project demonstrates how Python can be used to manage and analyze academic data efficiently.

By using simple data structures like 2D lists and built-in Python functions, we were able to build a system that organizes student grades and produces useful statistical insights.

Although the system is simple, it shows the power of programming in solving real-world problems.

Future improvements could include adding a graphical interface, exporting results to files, or connecting the system to a database.

Thank you for listening.

الترجمة بالعامية

في النهاية المشروع ده بيوضح إزاي نقدر نستخدم بايثون علشان ندير ونحلل بيانات أكاديمية بشكل فعال.

باستخدام هياكل بيانات بسيطة زي 2D Lists قدرنا نبني سيستم ينظم درجات الطلبة ويطلع تحليلات مفيدة.

ورغم إن السيستم بسيط، لكنه بيوضح قوة البرمجة في حل مشاكل حقيقية.

ممكن في المستقبل نطور السيستم بإضافة واجهة رسومية أو ربطه بقاعدة بيانات.

شكراً لحضراتكم.
