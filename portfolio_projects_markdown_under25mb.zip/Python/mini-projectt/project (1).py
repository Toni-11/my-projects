
while True:
    num_students = int(input("Enter the number of students: "))
    num_subjects = int(input("Enter the number of subjects: "))
    if num_students > 0 and num_subjects > 0:
        break
    print("Invalid input! Number of students and subjects must be greater than 0.")
    

students_grades = []



for i in range(num_students):
    print(f"\n--- Entering grades for Student number {i+1} ---")
    student_marks = []
    
    for j in range(num_subjects):
        while True:
            mark = float(input(f"  Enter grade for Subject number {j+1}: "))
            if 0 <= mark <= 100:
                student_marks.append(mark)
                break
            print("Invalid Grade! Please enter a value between 0 and 100.")
            
    students_grades.append(student_marks)


print("\n" + "="*30)
print("     PROJECT RESULTS")
print("="*30)


total_possible = num_subjects * 100

for i in range(num_students):
    student_sum = sum(students_grades[i])
    percentage = (student_sum / total_possible) * 100
    print(f"Student number {i+1}: Total = {student_sum}, Percentage = {percentage:.2f}%")

print("-" * 20)


for j in range(num_subjects):
    subject_grades = [students_grades[i][j] for i in range(num_students)]
    
    max_grade = max(subject_grades)
    min_grade = min(subject_grades)
    avg_grade = sum(subject_grades) / num_students
    
    top_student = subject_grades.index(max_grade) + 1
    low_student = subject_grades.index(min_grade) + 1
    
    print(f"Subject number {j+1}:")
    print(f"  - Average Grade: {avg_grade:.2f}")
    print(f"  - Highest: Student number {top_student} with {max_grade}")
    print(f"  - Lowest: Student number {low_student} with {min_grade}")