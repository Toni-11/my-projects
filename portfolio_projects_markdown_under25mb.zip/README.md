# Portfolio Projects

Academic and personal project collection.

## Categories
- Artificial Intelligence
- Machine Learning / Python
- C++
- Java OOP
- Software Engineering
- Digital Electronics

## File policy
Presentations and documentation are converted to Markdown where practical so the repository can stay lightweight and GitHub-friendly. Source-code files are preserved as provided. Binary-heavy assets are intentionally omitted from this lightweight package.
