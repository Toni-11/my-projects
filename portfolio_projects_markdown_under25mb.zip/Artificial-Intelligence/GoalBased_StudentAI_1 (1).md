# Presentation

## Slide 1

AI in Education

Goal-Based Student

AI System

An intelligent, goal-driven academic performance analyzer
that classifies students and generates personalized improvement plans.

Machine Learning  ·  Decision Trees  ·  Personalized Learning  ·  Data Analytics

Supervised By

Team Members

Antton Mikhael
                245455

Samy Tarek
245069

Michael Ibrahim
245528

Martin Romany
245531

Dr.Asmaa Mohamed
Eng.Salma Abdelmonem

## Slide 2

Problem & Motivation

One-size-fits-all

Traditional grading treats all students identically, ignoring individual strengths and weaknesses.

No Personalized Path

Students receive grades but no actionable roadmap to improve their academic standing.

Reactive, Not Proactive

Teachers only identify struggling students after poor exam results — too late for timely intervention.

The Goal-Based AI system was designed to solve all three problems simultaneously.

## Slide 3

System Architecture

Student
Grades Input

Feature
Extraction

Decision Tree
Classifier

Goal-Based
Planning

Personalized
Action Plan

Key Components:

Average grade + Standard deviation as ML features

Decision Tree Classifier trained on labeled student data

Goal definitions per level: Low → Medium → High

Subject-by-subject weak/strong analysis

## Slide 4

ML Classification Model

Decision Tree Classifier

Input Features: Average grade & Standard deviation

Output Labels: High (2)  ·  Medium (1)  ·  Low (0)

Train/Test Split: 80% / 20%  (random_state=42)

Library: scikit-learn DecisionTreeClassifier

Training Samples: 16 labeled student records

Performance Levels

HIGH

Avg ≥ 85  /  Std ≤ 8

Maintain excellence

MEDIUM

Avg 70–84  /  Std ≤ 12

Push toward High level

LOW

Avg < 70  /  Std > 12

Focus on weak subjects

## Slide 5

Goal-Based Planning Engine

Once a student's level is classified, the Goal-Based Agent generates a step-by-step improvement plan:

01

Identify Current Level

Retrieve the student's classification (Low / Medium / High) from the ML model output.

02

Compute Performance Gaps

Calculate how far the student's average and standard deviation are from the next-level targets.

03

Analyze Subjects

Flag subjects below 60 as weak and those above 80 as strong anchor subjects.

04

Generate Action Steps

Produce a ranked list: raise average, reduce variance, study weak subjects, leverage strong ones.

## Slide 6

Analytics & Output Reports

Per-Student Report

Current level classification

Average & standard deviation

Next target level

Step-by-step improvement plan

Class-Wide Analysis

Class mean average

Above/below class average flag

Gap from class mean for each student

Ranking within cohort

Subject Analysis

Per-subject average across all students

Top-performing student per subject

Lowest-performing student per subject

Subject health indicator

## Slide 7

Sample Output Visualization

Key Insights

High Level

S1, S4

Medium Level

S2, S6

Low Level

S3, S5

Class Mean

74.7

## Slide 8

Key Takeaways

Smarter Learning,
Better Outcomes.

Goal-Based AI bridges the gap between raw grades and meaningful feedback.

Decision Trees provide transparent, interpretable classification.

Class and subject analytics empower teachers as well as students.

Fully modular — easy to extend with new subjects, levels, or classifiers.

Goal-Based Student AI System  ·  Powered by scikit-learn & Python
