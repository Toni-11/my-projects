import statistics
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
 
# =========================================
# 1) TRAINING DATA
# =========================================
# Features: [average, std deviation]
X = [
    [90, 5], [85, 6], [88, 4], [92, 3],
    [70, 15], [75, 10], [72, 12], [68, 14],
    [60, 20], [55, 22], [50, 25], [58, 18],
    [95, 2], [93, 3], [78, 9], [65, 17]
]
# Labels: 2 = High, 1 = Medium, 0 = Low
y = [2, 2, 2, 2, 1, 1, 1, 1, 0, 0, 0, 0, 2, 2, 1, 0]
 
# =========================================
# 2) TRAIN MODEL
# =========================================
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
model = DecisionTreeClassifier()
model.fit(X_train, y_train)
 
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
 
print("=" * 50)
print(f"  Model Accuracy: {accuracy * 100:.2f}%")
print("=" * 50)
 
# =========================================
# 3) GOAL DEFINITIONS
#    Core of the Goal-Based Agent:
#    each level has a clear target and
#    a path to the next level.
# =========================================
GOALS = {
    2: {
        "label":      "High",
        "target_avg": 85,
        "target_std": 8,
        "next_level": None,
        "message":    "Excellent! Keep maintaining your high performance."
    },
    1: {
        "label":      "Medium",
        "target_avg": 85,
        "target_std": 8,
        "next_level": "High",
        "message":    "Good effort! You have the potential to reach High level."
    },
    0: {
        "label":      "Low",
        "target_avg": 70,
        "target_std": 12,
        "next_level": "Medium",
        "message":    "Needs improvement. Focus on weak subjects first."
    }
}
 
# =========================================
# 4) GOAL-BASED PLANNING FUNCTION
#    Analyses each student and produces a
#    personalised improvement plan.
# =========================================
def generate_goal_plan(student_marks, subject_labels, prediction):
    """
    Goal-Based Agent logic:
      1. Identify the current level.
      2. Define a clear goal.
      3. Calculate the gap.
      4. Generate step-by-step improvement actions.
    """
    goal = GOALS[prediction]
    avg  = sum(student_marks) / len(student_marks)
    std  = statistics.stdev(student_marks) if len(student_marks) > 1 else 0
 
    plan = {
        "current_level": goal["label"],
        "goal_message":  goal["message"],
        "next_level":    goal["next_level"],
        "steps":         []
    }
 
    # Categorise subjects
    weak_subjects   = []
    strong_subjects = []
    for mark, subject in zip(student_marks, subject_labels):
        if mark < 60:
            weak_subjects.append((subject, mark))
        elif mark >= 80:
            strong_subjects.append((subject, mark))
 
    # Calculate gaps
    avg_gap = goal["target_avg"] - avg
    std_gap = std - goal["target_std"]
 
    # Build improvement steps
    if avg_gap > 0:
        plan["steps"].append(
            f"Raise your average from {avg:.1f} to {goal['target_avg']} "
            f"(+{avg_gap:.1f} points needed)"
        )
 
    if std_gap > 0:
        plan["steps"].append(
            f"Reduce grade variance from {std:.1f} to {goal['target_std']} "
            f"— aim for more consistent scores across subjects"
        )
 
    if weak_subjects:
        names = ", ".join(f"{s} ({m:.0f})" for s, m in weak_subjects)
        plan["steps"].append(
            f"Weak subjects to prioritise: {names}"
        )
 
    if strong_subjects and prediction < 2:
        names = ", ".join(f"{s} ({m:.0f})" for s, m in strong_subjects)
        plan["steps"].append(
            f"Strong subjects to leverage for study strategies: {names}"
        )
 
    if not plan["steps"]:
        plan["steps"].append(
            "Outstanding performance across all subjects — keep it up!"
        )
 
    return plan
 
# =========================================
# 5) USER INPUT
# =========================================
while True:
    try:
        num_students = int(input("\nEnter number of students: "))
        num_subjects = int(input("Enter number of subjects : "))
        if num_students > 0 and num_subjects > 0:
            break
        else:
            print("Numbers must be greater than 0.")
    except ValueError:
        print("Invalid input. Please enter whole numbers.")
 
# Collect subject names
subject_labels = []
for j in range(num_subjects):
    name = input(f"Enter name for Subject {j + 1} (or press Enter to skip): ").strip()
    subject_labels.append(name if name else f"Subject {j + 1}")
 
# Collect student grades
students_grades = []
for i in range(num_students):
    print(f"\n--- Student {i + 1} ---")
    marks = []
    for j in range(num_subjects):
        while True:
            try:
                grade = float(input(f"  Grade for {subject_labels[j]}: "))
                if 0 <= grade <= 100:
                    marks.append(grade)
                    break
                else:
                    print("  Grade must be between 0 and 100.")
            except ValueError:
                print("  Invalid input. Please enter a number.")
    students_grades.append(marks)
 
# =========================================
# 6) GOAL-BASED AI ANALYSIS
# =========================================
print("\n" + "=" * 55)
print("        GOAL-BASED AI ANALYSIS RESULTS")
print("=" * 55)
 
class_averages = []
all_plans      = []
 
for i in range(num_students):
    marks      = students_grades[i]
    avg        = sum(marks) / num_subjects
    std        = statistics.stdev(marks) if len(marks) > 1 else 0
    prediction = model.predict([[avg, std]])[0]
 
    class_averages.append(avg)
    plan = generate_goal_plan(marks, subject_labels, prediction)
    all_plans.append(plan)
 
    print(f"\n{'─' * 50}")
    print(f"  Student {i + 1}")
    print(f"{'─' * 50}")
    print(f"  Total Score      : {sum(marks):.2f}")
    print(f"  Average          : {avg:.2f}")
    print(f"  Std Deviation    : {std:.2f}")
    print(f"  Current Level    : {plan['current_level']}")
    print(f"  Next Target      : "
          f"{plan['next_level'] if plan['next_level'] else 'Maintain current level'}")
    print(f"\n  {plan['goal_message']}")
    print(f"\n  Improvement Plan:")
    for step_num, step in enumerate(plan["steps"], 1):
        print(f"    {step_num}. {step}")
 
# =========================================
# 7) CLASS ANALYSIS
# =========================================
class_mean = sum(class_averages) / len(class_averages)
 
print(f"\n{'=' * 55}")
print(f"  CLASS PERFORMANCE  (Class Average: {class_mean:.2f})")
print(f"{'=' * 55}")
 
for i in range(num_students):
    gap    = class_averages[i] - class_mean
    status = "Above class average" if gap > 0 else "Below class average"
    print(f"  Student {i + 1}: {status}  ({gap:+.1f})")
 
# =========================================
# 8) SUBJECT ANALYSIS
# =========================================
print(f"\n{'=' * 55}")
print("  SUBJECT ANALYSIS")
print(f"{'=' * 55}")
 
for j in range(num_subjects):
    grades      = [students_grades[i][j] for i in range(num_students)]
    max_grade   = max(grades)
    min_grade   = min(grades)
    avg_grade   = sum(grades) / num_students
    top_student = grades.index(max_grade) + 1
    low_student = grades.index(min_grade) + 1
 
    print(f"\n  {subject_labels[j]}:")
    print(f"    Class Average : {avg_grade:.2f}")
    print(f"    Highest Score : Student {top_student} ({max_grade:.0f})")
    print(f"    Lowest Score  : Student {low_student} ({min_grade:.0f})")
 
print(f"\n{'=' * 55}")
print("  Analysis Complete — Goal-Based AI System")
print(f"{'=' * 55}\n")